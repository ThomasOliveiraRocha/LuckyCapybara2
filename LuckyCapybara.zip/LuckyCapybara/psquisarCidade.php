<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<h2>Pesquisar Elemento por Nome</h2>
<form method="post" action="pesquisar.php">
    <label for="cod_cidade">Código da Cidade:</label><br>
    <input type="text" id="cod_cidade" name="cod_cidade"><br><br>
    <input type="submit" value="Pesquisar">
</form>

</body>
</html>
