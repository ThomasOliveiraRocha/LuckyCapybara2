<!--
  Autores: <Thomas Oliveira>, <João Carvalho>, <Sandro Christe> e <André Oliveira>
  Data: <30/03/2024>
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caça Niquel</title>
</head>
<body>

  <div id="todo1">
		<?php 
			//Encerra a execucao do carregamento da pagina caso o arquivo contenha erros.
			//Nao usou 'require_once' porque outras páginas podem invocar o conteudo de 'db_sqlite.php' novamente.
			require("db_mysql.php");   
		?>
	</div>
    
</body>
</html>o
